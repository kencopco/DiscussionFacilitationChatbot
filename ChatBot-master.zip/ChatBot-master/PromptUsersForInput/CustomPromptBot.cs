﻿// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Schema;
using Microsoft.Extensions.Logging;
using Microsoft.Recognizers.Text;
using Microsoft.Recognizers.Text.DateTime;
using Microsoft.Recognizers.Text.Number;

namespace Microsoft.BotBuilderSamples
{
    /// <summary>
    /// Represents a bot that processes incoming activities.
    /// For each user interaction, an instance of this class is created and the OnTurnAsync method is called.
    /// This is a Transient lifetime service.  Transient lifetime services are created
    /// each time they're requested. For each Activity received, a new instance of this
    /// class is created. Objects that are expensive to construct, or have a lifetime
    /// beyond the single turn, should be carefully managed.
    /// For example, the <see cref="MemoryStorage"/> object and associated
    /// <see cref="IStatePropertyAccessor{T}"/> object are created with a singleton lifetime.
    /// </summary>
    /// <seealso cref="https://docs.microsoft.com/en-us/aspnet/core/fundamentals/dependency-injection?view=aspnetcore-2.1"/>
    public class CustomPromptBot : IBot
    {
        private readonly CustomPromptBotAccessors _accessors;
        private readonly ILogger _logger;

        /// <summary>
        /// Initializes a new instance of the <see cref="CustomPromptBot"/> class.
        /// </summary>
        /// <param name="accessors">A class containing <see cref="IStatePropertyAccessor{T}"/> used to manage state.</param>
        /// <param name="loggerFactory">A <see cref="ILoggerFactory"/> that is hooked to the Azure App Service provider.</param>
        /// <remarks>Defines a bot for filling a user profile.</remarks>
        /// <seealso cref="https://docs.microsoft.com/en-us/aspnet/core/fundamentals/logging/?view=aspnetcore-2.1#windows-eventlog-provider"/>
        public CustomPromptBot(CustomPromptBotAccessors accessors, ILoggerFactory loggerFactory)
        {
            if (loggerFactory == null)
            {
                throw new System.ArgumentNullException(nameof(loggerFactory));
            }

            _logger = loggerFactory.CreateLogger<CustomPromptBot>();
            _logger.LogTrace("EchoBot turn start.");
            _accessors = accessors ?? throw new System.ArgumentNullException(nameof(accessors));
        }

        /// <summary>The turn handler for the bot.</summary>
        /// <param name="turnContext">A <see cref="ITurnContext"/> containing all the data needed
        /// for processing this conversation turn. </param>
        /// <param name="cancellationToken">(Optional) A <see cref="CancellationToken"/> that can be used by other objects
        /// or threads to receive notice of cancellation.</param>
        /// <returns>A <see cref="Task"/> that represents the work queued to execute.</returns>
        public async Task OnTurnAsync(ITurnContext turnContext, CancellationToken cancellationToken = default(CancellationToken))
        {

            var responseMessage = $"Hello\n";
            // Handle Message activity type, which is the main activity type for shown within a conversational interface
            // Message activities may contain text, speech, interactive cards, and binary or unknown attachments.
            // see https://aka.ms/about-bot-activity-message to learn more about the message and other activity types
            if (turnContext.Activity.Type == ActivityTypes.Message)
            {
                // Get the state properties from the turn context.
                ConversationFlow flow = await _accessors.ConversationFlowAccessor.GetAsync(turnContext, () => new ConversationFlow());
              //  ConversationFlow flowTwo = await _accessors.ConversationFlowAccessor.GetAsync(turnContext, () => new ConversationFlow());
                UserProfile profile = await _accessors.UserProfileAccessor.GetAsync(turnContext, () => new UserProfile());
               // UserProfile profileTwo = await _accessors.UserProfileAccessor.GetAsync(turnContext, () => new UserProfile());
                //Maybe set it up for 3 users to put in questions then after all questions in assign to each name saved
            


                   //await turnContext.SendActivityAsync(responseMessage);
                    await FillOutUserProfileAsync(flow, profile, turnContext);


                // Update state and save changes.

                await _accessors.ConversationFlowAccessor.SetAsync(turnContext, flow);
                await _accessors.ConversationState.SaveChangesAsync(turnContext);

                await _accessors.UserProfileAccessor.SetAsync(turnContext, profile);
                await _accessors.UserState.SaveChangesAsync(turnContext);
            }
        }

        /// <summary>
        /// Manages the conversation flow for filling out the user's profile, including parsing and validation.
        /// </summary>
        /// <param name="flow">The conversation flow state property.</param>
        /// <param name="profile">The user profile state property.</param>
        /// <param name="turnContext">The context object for the current turn.</param>
        /// <returns>A task that represents the work queued to execute.</returns>
        private static async Task FillOutUserProfileAsync(ConversationFlow flow, UserProfile profile, ITurnContext turnContext)
        {
            string input = turnContext.Activity.Text?.Trim();
            string message;

            switch (flow.LastQuestionAsked)
            {
               case ConversationFlow.Question.None:
                     await turnContext.SendActivityAsync("Let's get started. What your name?");
                     flow.LastQuestionAsked = ConversationFlow.Question.Name;
                    break;
                case ConversationFlow.Question.Name:
                    if (ValidateName(input, out string name, out message))
                    {
                        profile.Name = name;
                        await turnContext.SendActivityAsync($"Hi {profile.Name}.");
                        await turnContext.SendActivityAsync("Please give one discussion question.");
                        flow.LastQuestionAsked = ConversationFlow.Question.DiscQuestion;
                        break;
                    }
                    else
                    {
                        await turnContext.SendActivityAsync(message ?? "I'm sorry, I didn't understand that.");
                        break;
                    }

                case ConversationFlow.Question.DiscQuestion:

                    if (ValidateName(input, out string discQuestion, out message))
                    {
                        profile.DiscQuestion = discQuestion;
                        //await turnContext.SendActivityAsync($"Can anyone answer {profile.Name}?");
                        //await turnContext.SendActivityAsync($"{profile.DiscQuestion}");
                        await turnContext.SendActivityAsync($"Thank you {profile.Name}");
                        await turnContext.SendActivityAsync("Next student. Please enter your name.");
                        flow.LastQuestionAsked = ConversationFlow.Question.NoneTwo;
                        
                        
                        break;
                      //  break;
                    }
                    else
                    {
                        await turnContext.SendActivityAsync(message ?? "I'm sorry, I didn't understand that.");
                        break;
                    }


                case ConversationFlow.Question.NoneTwo:
                        profile.NameTwo = input;
                        await turnContext.SendActivityAsync($"Thank you {profile.NameTwo}. Can you provide me with a discussion question?");
                        flow.LastQuestionAsked = ConversationFlow.Question.NameTwo;
                        break;

                case ConversationFlow.Question.NameTwo:
                    if (ValidateName(input, out string DiscQuestionTwo, out message))
                    {
                        profile.DiscQuestionTwo = DiscQuestionTwo;
                        await turnContext.SendActivityAsync($"Thank you {profile.NameTwo}.");
                        await turnContext.SendActivityAsync("Final person please enter your name.");
                        flow.LastQuestionAsked = ConversationFlow.Question.NameThree;
                        break;
                    }
                    else
                    {
                        await turnContext.SendActivityAsync(message ?? "I'm sorry, I didn't understand that.");
                        break;
                    }

                case ConversationFlow.Question.NameThree:
                    profile.NameThree = input;
                    await turnContext.SendActivityAsync($"Thank you {profile.NameThree}. Please provide your discussion question.");
                    flow.LastQuestionAsked = ConversationFlow.Question.DiscQuestionTwo;
                    break;

                case ConversationFlow.Question.DiscQuestionTwo:

                    if (ValidateName(input, out string discQuestionThree, out message))
                    {
                        profile.DiscQuestionThree = discQuestionThree;
                        //await turnContext.SendActivityAsync($"Can anyone answer {profile.Name}?");
                        //await turnContext.SendActivityAsync($"{profile.DiscQuestion}");
                        await turnContext.SendActivityAsync($"Thank you {profile.NameThree}");
                        await turnContext.SendActivityAsync($"Are you finished entering responses??");

                        
                        flow.LastQuestionAsked = ConversationFlow.Question.Done;


                        break;
                        //  break;
                    }
                    else
                    {
                        await turnContext.SendActivityAsync(message ?? "I'm sorry, I didn't understand that.");
                        break;
                    }



                case ConversationFlow.Question.Done:
                    {
                        await turnContext.SendActivityAsync($"{profile.Name} please answer the following question.");
                        await turnContext.SendActivityAsync($"{profile.DiscQuestionThree}");
                        await turnContext.SendActivityAsync($"{profile.NameThree} please answer the following question.");
                        await turnContext.SendActivityAsync($"{profile.DiscQuestionTwo}");
                        await turnContext.SendActivityAsync($"{profile.NameTwo} please answer the following question.");
                        await turnContext.SendActivityAsync($"{profile.DiscQuestion}");

                        await turnContext.SendActivityAsync($"Thank you for using discussion chat bot. Please have a nice day!\n");
                        break;
                    }


                    /*
                                    case ConversationFlow.Question.DiscAnswer:

                                        if (ValidateName(input, out string discAnswer, out message))
                                        {
                                            profile.DiscQuestion = discAnswer;
                                            profile.Date = "done";

                                            // await turnContext.SendActivityAsync($"Thank you, does anyone have an other thoughts about \"{profile.DiscQuestion}\"");
                                            //await turnContext.SendActivityAsync($"What is your name sir?");
                                            //await turnContext.SendActivityAsync($"{profile.Date}");
                                            //flow.LastQuestionAsked = ConversationFlow.Question.None;
                                            return;
                                           // break;
                                        }
                                        else
                                        {
                                            await turnContext.SendActivityAsync(message ?? "I'm sorry, I didn't understand that.");
                                            break;
                                        }
                       */






            }
        }

        /// <summary>
        /// Validates name input.
        /// </summary>
        /// <param name="input">The user's input.</param>
        /// <param name="name">When the method returns, contains the normalized name, if validation succeeded.</param>
        /// <param name="message">When the method returns, contains a message with which to reprompt, if validation failed.</param>
        /// <returns>indicates whether validation succeeded.</returns>
        private static bool ValidateName(string input, out string name, out string message)
        {
            name = null;
            message = null;

            if (string.IsNullOrWhiteSpace(input))
            {
                message = "Please enter a name that contains at least one character.";
            }
            else
            {
                name = input.Trim();
            }

            return message is null;
        }

        /// <summary>
        /// Validates age input.
        /// </summary>
        /// <param name="input">The user's input.</param>
        /// <param name="age">When the method returns, contains the normalized age, if validation succeeded.</param>
        /// <param name="message">When the method returns, contains a message with which to reprompt, if validation failed.</param>
        /// <returns>indicates whether validation succeeded.</returns>
        private static bool ValidateAge(string input, out int age, out string message)
        {
            age = 0;
            message = null;

            // Try to recognize the input as a number. This works for responses such as "twelve" as well as "12".
            try
            {
                // Attempt to convert the Recognizer result to an integer. This works for "a dozen", "twelve", "12", and so on.
                // The recognizer returns a list of potential recognition results, if any.
                List<ModelResult> results = NumberRecognizer.RecognizeNumber(input, Culture.English);
                foreach (ModelResult result in results)
                {
                    // The result resolution is a dictionary, where the "value" entry contains the processed string.
                    if (result.Resolution.TryGetValue("value", out object value))
                    {
                        age = Convert.ToInt32(value);
                        if (age >= 18 && age <= 120)
                        {
                            return true;
                        }
                    }
                }

                message = "Please enter an age between 18 and 120.";
            }
            catch
            {
                message = "I'm sorry, I could not interpret that as an age. Please enter an age between 18 and 120.";
            }

            return message is null;
        }

        /// <summary>
        /// Validates flight time input.
        /// </summary>
        /// <param name="input">The user's input.</param>
        /// <param name="date">When the method returns, contains the normalized date, if validation succeeded.</param>
        /// <param name="message">When the method returns, contains a message with which to reprompt, if validation failed.</param>
        /// <returns>indicates whether validation succeeded.</returns>
        private static bool ValidateDate(string input, out string date, out string message)
        {
            date = null;
            message = null;

            // Try to recognize the input as a date-time. This works for responses such as "11/14/2018", "9pm", "tomorrow", "Sunday at 5pm", and so on.
            // The recognizer returns a list of potential recognition results, if any.
            try
            {
                List<ModelResult> results = DateTimeRecognizer.RecognizeDateTime(input, Culture.English);

                // Check whether any of the recognized date-times are appropriate,
                // and if so, return the first appropriate date-time. We're checking for a value at least an hour in the future.
                DateTime earliest = DateTime.Now.AddHours(1.0);
                foreach (ModelResult result in results)
                {
                    // The result resolution is a dictionary, where the "values" entry contains the processed input.
                    List<Dictionary<string, string>> resolutions = result.Resolution["values"] as List<Dictionary<string, string>>;
                    foreach (Dictionary<string, string> resolution in resolutions)
                    {
                        // The processed input contains a "value" entry if it is a date-time value, or "start" and
                        // "end" entries if it is a date-time range.
                        if (resolution.TryGetValue("value", out string dateString)
                            || resolution.TryGetValue("start", out dateString))
                        {
                            if (DateTime.TryParse(dateString, out DateTime candidate)
                                && earliest < candidate)
                            {
                                date = candidate.ToShortDateString();
                                return true;
                            }
                        }
                    }
                }

                message = "I'm sorry, please enter a date at least an hour out.";
            }
            catch
            {
                message = "I'm sorry, I could not interpret that as an appropriate date. Please enter a date at least an hour out.";
            }

            return false;
        }
    }
}
