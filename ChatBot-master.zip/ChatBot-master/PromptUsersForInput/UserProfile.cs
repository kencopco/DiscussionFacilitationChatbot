﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Microsoft.BotBuilderSamples
{
    public class UserProfile
    {
        public string Name { get; set; }

        public string NameTwo { get; set; }

        public string NameThree { get; set; }

        public string DiscQuestion { get; set; }

        public string DiscQuestionTwo { get; set; }

        public string DiscQuestionThree { get; set; }

        public string Date { get; set; }

        public string DiscAnswer { get; set; }

    }
}
