﻿// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

using System.Threading;
using System.Threading.Tasks;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Schema;
using Microsoft.Extensions.Logging;

namespace EchoBot3
{
    /// <summary>
    /// Represents a bot that processes incoming activities.
    /// For each user interaction, an instance of this class is created and the OnTurnAsync method is called.
    /// This is a Transient lifetime service.  Transient lifetime services are created
    /// each time they're requested. For each Activity received, a new instance of this
    /// class is created. Objects that are expensive to construct, or have a lifetime
    /// beyond the single turn, should be carefully managed.
    /// For example, the <see cref="MemoryStorage"/> object and associated
    /// <see cref="IStatePropertyAccessor{T}"/> object are created with a singleton lifetime.
    /// </summary>
    /// <seealso cref="https://docs.microsoft.com/en-us/aspnet/core/fundamentals/dependency-injection?view=aspnetcore-2.1"/>
    public class EchoBot3Bot : IBot
    {
        private readonly EchoBot3Accessors _accessors;
        private readonly ILogger _logger;

        /// <summary>
        /// Initializes a new instance of the class.
        /// </summary>
        /// <param name="conversationState">The managed conversation state.</param>
        /// <param name="loggerFactory">A <see cref="ILoggerFactory"/> that is hooked to the Azure App Service provider.</param>
        /// <seealso cref="https://docs.microsoft.com/en-us/aspnet/core/fundamentals/logging/?view=aspnetcore-2.1#windows-eventlog-provider"/>
        public EchoBot3Bot(ConversationState conversationState, ILoggerFactory loggerFactory)
        {
            if (conversationState == null)
            {
                throw new System.ArgumentNullException(nameof(conversationState));
            }

            if (loggerFactory == null)
            {
                throw new System.ArgumentNullException(nameof(loggerFactory));
            }

            _accessors = new EchoBot3Accessors(conversationState)
            {
                CounterState = conversationState.CreateProperty<CounterState>(EchoBot3Accessors.CounterStateName),
            };

            _logger = loggerFactory.CreateLogger<EchoBot3Bot>();
            _logger.LogTrace("Turn start.");
        }

        /// <summary>
        /// Every conversation turn for our Echo Bot will call this method.
        /// There are no dialogs used, since it's "single turn" processing, meaning a single
        /// request and response.
        /// </summary>
        /// <param name="turnContext">A <see cref="ITurnContext"/> containing all the data needed
        /// for processing this conversation turn. </param>
        /// <param name="cancellationToken">(Optional) A <see cref="CancellationToken"/> that can be used by other objects
        /// or threads to receive notice of cancellation.</param>
        /// <returns>A <see cref="Task"/> that represents the work queued to execute.</returns>
        /// <seealso cref="BotStateSet"/>
        /// <seealso cref="ConversationState"/>
        /// <seealso cref="IMiddleware"/>
        public async Task OnTurnAsync(ITurnContext turnContext, CancellationToken cancellationToken = default(CancellationToken))
        {
            // Handle Message activity type, which is the main activity type for shown within a conversational interface
            // Message activities may contain text, speech, interactive cards, and binary or unknown attachments.
            // see https://aka.ms/about-bot-activity-message to learn more about the message and other activity types
            string topic = "";

            if (turnContext.Activity.Type == ActivityTypes.Message)
            {
                // Get the conversation state from the turn context.
                var state = await _accessors.CounterState.GetAsync(turnContext, () => new CounterState());

                // Bump the turn count for this conversation.
                state.TurnCount++;

                // Set the property using the accessor.
                await _accessors.CounterState.SetAsync(turnContext, state);

                // Save the new turn count into the conversation state.
                await _accessors.ConversationState.SaveChangesAsync(turnContext);

                // Echo back to the user whatever they typed.

                var responseMessage = $"Turn {state.TurnCount}: You sent '{turnContext.Activity.Text}'\n";

                if (state.TurnCount == 1) {

                    responseMessage = $"Is this discussion going to be technical or non-technical?";
                } else if (turnContext.Activity.Text == "Technical question discussion.")
                {
                    responseMessage = "(technical) What topics do you want to discuss? ";
                } else if (turnContext.Activity.Text == "Tornados.")
                {
                    responseMessage = "What’s the question you have about tornados?";
                } else if (turnContext.Activity.Text == "What could have cause a sharp increase in significant tornadoes?")
                {
                    responseMessage = "What is your understanding of tornados?";
                } else if (turnContext.Activity.Text == "Tornadoes are violently rotating air column between a cloud and Earth that extend from a thunderstorm to the ground. Increasing number of tornadoes can be a result of global warming in the climate change.")
                {
                    responseMessage = "Are there opposing views or conflicting theories concerning tornados? If so, describe two.If not, why not ?";
                } else if (turnContext.Activity.Text.Contains ("Opposing to global warming reason:"))
                {
                    responseMessage = "What else?";
                } else if (turnContext.Activity.Text.Contains("Opposing to use of F scale"))
                {
                    responseMessage = "Good. You can also see https://en.wikipedia.org/wiki/Tornado";
                } else if (turnContext.Activity.Text == "Albert Einstein is great.")
                {
                    responseMessage = "Ok";
                } else if (turnContext.Activity.Text == "Albert Einstein is my favorite person.")
                {
                    responseMessage = "Fine";
                } else if (turnContext.Activity.Text == "Albert Einstein is the smartest.")
                {
                    responseMessage = "Would you like to know more about Albert Einstein?";
                } else if (turnContext.Activity.Text == "Yes, please")
                {
                    responseMessage = "Please find more information at https://en.wikipedia.org/wiki/Albert_Einstein. Do you have any other questions?";
                }else if (turnContext.Activity.Text == "No thank you")
                {
                    responseMessage = "Ok, goodbye";
                }else if (turnContext.Activity.Text == "Non-Technical question discussion.")
                {
                    responseMessage = "(non-technical) What topics do you want to discuss?";
                }else if (turnContext.Activity.Text == "Justice")
                {
                    responseMessage = "Can you name one of the four parts?";
                }else if (turnContext.Activity.Text == "Distributive")
                {
                    responseMessage = "Distributive: Justice ensures that people gets their fair share of the benefits and resources available. Can you name another?";
                }else if (turnContext.Activity.Text == "Procedural")
                {
                    responseMessage = "Good, here are rest of the definitions. \n\nProcedural: Justice is concerned with fair treatment to generate unbiased decisions.\n Restorative: Justice is considered to address any injustices sufficiently as well as to restore interpersonal relationship.\n Retributive: Justice appeals to the idea of fair play that people justifies punishment as a result of wrongdoing";
                }




                    /*
                                    if (turnContext.Activity.Text.Contains("hello") || turnContext.Activity.Text.Contains("Hello"))
                                    {
                                        responseMessage = $"Hi, how are you?";

                                    }else if (turnContext.Activity.Text.Contains("non-technical"))
                                    {

                                        responseMessage = $"I see you would like a non-techical discussion. What is your topic?";
                                    }else if (turnContext.Activity.Text.Contains("technical"))
                                    {

                                        responseMessage = $"I see you would like a techical discussion. What is your topic?";
                                    }else if (state.TurnCount == 3)
                                    {
                                        responseMessage = $"What is your understanding of tornados?";
                                    }else if (state.TurnCount == 4)
                                    {
                                        responseMessage = $"Are there opposing views or conflicting theories concerning" + topic + "If so, describe two. If not, why not ?";
                                    }
                    /*
                                    if (turnContext.Activity.Text.Contains("george washington") || turnContext.Activity.Text.Contains("George Washington"))
                                    {
                                        responseMessage = $"Please see https://en.wikipedia.org/wiki/George_Washington for more information.";

                                    }

                                    if (turnContext.Activity.Text.Contains("war") || turnContext.Activity.Text.Contains("war of 1812"))
                                    {
                                        responseMessage = $"Please see https://en.wikipedia.org/wiki/War_of_1812 for more information.";

                                    }

                                    string myTemp = (string)turnContext.Activity.Text;
                                    myTemp.Replace(' ', '+');
                                    //Console.WriteLine("Welcome to the C# Station Tutorial!");
                                    responseMessage = $"Please see https://www.google.com/search?q=" + myTemp + " for more information";
                                    //myTemp = (string)responseMessage;


                                   // responseMessage = myTemp;




                    */

                    // var responseMessage = $"Turn {state.TurnCount}: You sent '{turnContext.Activity.Text}'\n";
                    await turnContext.SendActivityAsync(responseMessage);
            }
            else
            {
                await turnContext.SendActivityAsync($"{turnContext.Activity.Type} event detected");
            }
        }
    }
}
